import warnings
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
import streamlit as st
import yfinance as yf
import plotly.graph_objects as go
import plotly.express as px

from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.linear_model import LogisticRegression
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    mean_absolute_error, mean_squared_error, r2_score,
    confusion_matrix
)

st.set_page_config(
    page_title="Sustainable Stock ML Analytics",
    page_icon="📈",
    layout="wide"
)

st.title("📈 Sustainable Stock Market Analysis & Prediction")
st.caption("A Statistical Machine Learning project aligned with SDG 7, SDG 8 and SDG 9.")

st.info(
    "Educational project only. Model outputs are experimental estimates, not financial "
    "advice or guaranteed forecasts. Stock prices are uncertain and can move sharply."
)

DEFAULT_TICKERS = [
    "TATAPOWER.NS", "ADANIGREEN.NS", "NTPC.NS", "POWERGRID.NS",
    "SUZLON.NS", "RELIANCE.NS", "TCS.NS", "HDFCBANK.NS"
]

# This is an illustrative research watchlist, not an official ESG rating.
ENERGY_TRANSITION_WATCHLIST = [
    "TATAPOWER.NS", "ADANIGREEN.NS", "NTPC.NS",
    "POWERGRID.NS", "SUZLON.NS"
]

@st.cache_data(ttl=900, show_spinner=False)
def download_stock(ticker: str, period: str) -> pd.DataFrame:
    data = yf.download(
        ticker, period=period, interval="1d",
        auto_adjust=True, progress=False, threads=False
    )
    if data is None or data.empty:
        return pd.DataFrame()

    # yfinance may return either ordinary columns or a MultiIndex.
    if isinstance(data.columns, pd.MultiIndex):
        data.columns = data.columns.get_level_values(0)

    needed = ["Open", "High", "Low", "Close", "Volume"]
    if not all(col in data.columns for col in needed):
        return pd.DataFrame()

    data = data[needed].copy()
    for col in needed:
        data[col] = pd.to_numeric(data[col], errors="coerce")
    data = data.dropna()
    data.index = pd.to_datetime(data.index)
    return data

def rsi(series: pd.Series, window: int = 14) -> pd.Series:
    delta = series.diff()
    gain = delta.clip(lower=0).rolling(window).mean()
    loss = (-delta.clip(upper=0)).rolling(window).mean()
    rs = gain / loss.replace(0, np.nan)
    return 100 - (100 / (1 + rs))

def build_features(raw: pd.DataFrame) -> pd.DataFrame:
    df = raw.copy()
    close = df["Close"]
    df["Return"] = close.pct_change()
    df["Return_1"] = df["Return"]
    df["Return_2"] = close.pct_change(2)
    df["Return_5"] = close.pct_change(5)
    df["SMA_5"] = close.rolling(5).mean()
    df["SMA_10"] = close.rolling(10).mean()
    df["SMA_20"] = close.rolling(20).mean()
    df["SMA_50"] = close.rolling(50).mean()
    df["EMA_12"] = close.ewm(span=12, adjust=False).mean()
    df["EMA_26"] = close.ewm(span=26, adjust=False).mean()
    df["MACD"] = df["EMA_12"] - df["EMA_26"]
    df["MACD_Signal"] = df["MACD"].ewm(span=9, adjust=False).mean()
    df["RSI"] = rsi(close)
    df["Volatility_10"] = df["Return"].rolling(10).std()
    df["Volatility_20"] = df["Return"].rolling(20).std()
    df["Volume_Change"] = df["Volume"].pct_change()
    df["Volume_SMA_10"] = df["Volume"].rolling(10).mean()
    rolling_mean = close.rolling(20).mean()
    rolling_std = close.rolling(20).std()
    df["BB_Upper"] = rolling_mean + 2 * rolling_std
    df["BB_Lower"] = rolling_mean - 2 * rolling_std

    # Targets are shifted backward: features on day t predict return/direction on t+1.
    df["Target_Return"] = df["Return"].shift(-1)
    df["Target_Direction"] = (df["Target_Return"] > 0).astype(int)
    return df.replace([np.inf, -np.inf], np.nan)

FEATURES = [
    "Return_1", "Return_2", "Return_5", "SMA_5", "SMA_10", "SMA_20",
    "EMA_12", "EMA_26", "MACD", "MACD_Signal", "RSI",
    "Volatility_10", "Volatility_20", "Volume_Change", "Volume_SMA_10"
]

def train_and_evaluate(df: pd.DataFrame):
    dataset = df.dropna(subset=FEATURES + ["Target_Direction", "Target_Return"]).copy()
    if len(dataset) < 100:
        raise ValueError("Not enough usable data. Choose a longer history period.")

    X = dataset[FEATURES]
    y_class = dataset["Target_Direction"].astype(int)
    y_reg = dataset["Target_Return"].astype(float)

    split = int(len(dataset) * 0.80)
    if split < 50 or len(dataset) - split < 15:
        raise ValueError("Not enough observations for a reliable chronological split.")

    X_train, X_test = X.iloc[:split], X.iloc[split:]
    yc_train, yc_test = y_class.iloc[:split], y_class.iloc[split:]
    yr_train, yr_test = y_reg.iloc[:split], y_reg.iloc[split:]

    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    logistic = LogisticRegression(max_iter=2000, class_weight="balanced")
    logistic.fit(X_train_scaled, yc_train)

    forest = RandomForestClassifier(
        n_estimators=300, max_depth=8, min_samples_leaf=4,
        random_state=42, class_weight="balanced_subsample"
    )
    forest.fit(X_train, yc_train)

    regressor = RandomForestRegressor(
        n_estimators=300, max_depth=8, min_samples_leaf=4,
        random_state=42
    )
    regressor.fit(X_train, yr_train)

    predictions = {
        "Logistic Regression": logistic.predict(X_test_scaled),
        "Random Forest": forest.predict(X_test)
    }

    metrics = []
    for name, pred in predictions.items():
        metrics.append({
            "Model": name,
            "Accuracy": accuracy_score(yc_test, pred),
            "Precision": precision_score(yc_test, pred, zero_division=0),
            "Recall": recall_score(yc_test, pred, zero_division=0),
            "F1-score": f1_score(yc_test, pred, zero_division=0)
        })

    reg_pred = regressor.predict(X_test)
    reg_metrics = {
        "MAE": mean_absolute_error(yr_test, reg_pred),
        "RMSE": np.sqrt(mean_squared_error(yr_test, reg_pred)),
        "R2": r2_score(yr_test, reg_pred)
    }

    latest_x = df.dropna(subset=FEATURES)[FEATURES].iloc[[-1]]
    latest_scaled = scaler.transform(latest_x)
    next_direction = int(forest.predict(latest_x)[0])
    probabilities = forest.predict_proba(latest_x)[0]
    next_return = float(regressor.predict(latest_x)[0])

    importance = pd.DataFrame({
        "Feature": FEATURES,
        "Importance": forest.feature_importances_
    }).sort_values("Importance", ascending=False)

    return {
        "dataset": dataset, "split": split, "metrics": pd.DataFrame(metrics),
        "reg_metrics": reg_metrics, "reg_pred": reg_pred, "yr_test": yr_test,
        "forest": forest, "logistic": logistic, "scaler": scaler,
        "next_direction": next_direction, "probabilities": probabilities,
        "next_return": next_return, "importance": importance,
        "y_test": yc_test, "rf_test_pred": predictions["Random Forest"]
    }

def risk_label(volatility: float) -> str:
    # Annualized historical volatility bands; illustrative project thresholds.
    annualized = volatility * np.sqrt(252)
    if annualized < 0.20:
        return "Lower historical volatility"
    if annualized < 0.40:
        return "Moderate historical volatility"
    return "Higher historical volatility"

with st.sidebar:
    st.header("⚙️ Project Controls")
    ticker = st.text_input("Stock ticker", value="TATAPOWER.NS").strip().upper()
    period = st.selectbox("Historical data period", ["1y", "2y", "5y", "10y"], index=2)
    st.caption("Indian NSE tickers commonly end in .NS. Example: RELIANCE.NS")
    run_button = st.button("Run stock analysis", type="primary", use_container_width=True)
    st.divider()
    st.markdown("**Example tickers**")
    st.code("TATAPOWER.NS\nADANIGREEN.NS\nNTPC.NS\nRELIANCE.NS\nTCS.NS")

if "run" not in st.session_state:
    st.session_state.run = True
if run_button:
    st.session_state.run = True

if st.session_state.run:
    if not ticker:
        st.error("Enter a valid stock ticker.")
        st.stop()

    with st.spinner(f"Downloading and analyzing {ticker}..."):
        raw = download_stock(ticker, period)

    if raw.empty or len(raw) < 150:
        st.error(
            "Could not retrieve enough historical data for this ticker. Check the symbol "
            "and internet connection, or try a more common ticker such as RELIANCE.NS."
        )
        st.stop()

    data = build_features(raw)
    latest = raw.iloc[-1]
    first_close = float(raw["Close"].iloc[0])
    last_close = float(latest["Close"])
    total_return = (last_close / first_close - 1) * 100
    daily_vol = float(data["Return"].dropna().tail(20).std())
    label = risk_label(daily_vol)

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Latest adjusted close", f"{last_close:,.2f}")
    c2.metric(f"Return over {period}", f"{total_return:.2f}%")
    c3.metric("20-day annualized volatility", f"{daily_vol*np.sqrt(252)*100:.2f}%")
    c4.metric("Historical risk band", label)

    tab1, tab2, tab3, tab4, tab5 = st.tabs([
        "📊 Overview", "🤖 ML Prediction", "⚠️ Risk Analysis",
        "🌱 SDG & Sector View", "📘 Methodology"
    ])

    with tab1:
        st.subheader(f"{ticker} — Historical market performance")
        fig = go.Figure(data=[go.Candlestick(
            x=raw.index, open=raw["Open"], high=raw["High"],
            low=raw["Low"], close=raw["Close"], name="Price"
        )])
        fig.update_layout(height=480, xaxis_rangeslider_visible=False,
                          yaxis_title="Adjusted price", template="plotly_white")
        st.plotly_chart(fig, use_container_width=True)

        col_a, col_b = st.columns(2)
        with col_a:
            st.markdown("**Moving averages**")
            ma_fig = go.Figure()
            ma_fig.add_trace(go.Scatter(x=data.index, y=data["Close"], name="Close"))
            ma_fig.add_trace(go.Scatter(x=data.index, y=data["SMA_20"], name="SMA 20"))
            ma_fig.add_trace(go.Scatter(x=data.index, y=data["SMA_50"], name="SMA 50"))
            ma_fig.update_layout(height=330, template="plotly_white")
            st.plotly_chart(ma_fig, use_container_width=True)
        with col_b:
            st.markdown("**Trading volume**")
            vol_fig = px.bar(x=raw.index, y=raw["Volume"], labels={"x": "Date", "y": "Volume"})
            vol_fig.update_layout(height=330, template="plotly_white")
            st.plotly_chart(vol_fig, use_container_width=True)

        st.markdown("**Technical indicators**")
        ind1, ind2 = st.columns(2)
        with ind1:
            rsi_fig = px.line(data, x=data.index, y="RSI", title="Relative Strength Index (RSI)")
            rsi_fig.add_hline(y=70, line_dash="dash")
            rsi_fig.add_hline(y=30, line_dash="dash")
            rsi_fig.update_layout(height=300, template="plotly_white")
            st.plotly_chart(rsi_fig, use_container_width=True)
        with ind2:
            macd_fig = go.Figure()
            macd_fig.add_trace(go.Scatter(x=data.index, y=data["MACD"], name="MACD"))
            macd_fig.add_trace(go.Scatter(x=data.index, y=data["MACD_Signal"], name="Signal"))
            macd_fig.update_layout(title="MACD", height=300, template="plotly_white")
            st.plotly_chart(macd_fig, use_container_width=True)

        st.markdown("**Recent market data**")
        st.dataframe(raw.tail(10).sort_index(ascending=False), use_container_width=True)

    with tab2:
        st.subheader("Next-trading-day ML estimates")
        try:
            result = train_and_evaluate(data)
        except Exception as exc:
            st.error(f"Model training could not complete: {exc}")
            st.stop()

        pred_col1, pred_col2, pred_col3 = st.columns(3)
        direction_text = "UP" if result["next_direction"] == 1 else "DOWN"
        pred_col1.metric("Random Forest direction", direction_text)
        pred_col2.metric("Estimated next-day return", f"{result['next_return']*100:.3f}%")
        confidence = float(result["probabilities"][result["next_direction"]]) * 100
        pred_col3.metric("Model class probability", f"{confidence:.1f}%")

        st.caption(
            "The class probability is the model's estimated probability, not a calibrated "
            "chance of profit. A direction prediction is not a trading recommendation."
        )

        st.markdown("**Classification model comparison — chronological test set**")
        st.dataframe(result["metrics"].style.format({
            "Accuracy": "{:.3f}", "Precision": "{:.3f}",
            "Recall": "{:.3f}", "F1-score": "{:.3f}"
        }), use_container_width=True)

        best = result["metrics"].sort_values("F1-score", ascending=False).iloc[0]
        st.write(f"Highest test-set F1-score in this run: **{best['Model']}** ({best['F1-score']:.3f}).")

        st.markdown("**Regression model performance**")
        rm = result["reg_metrics"]
        m1, m2, m3 = st.columns(3)
        m1.metric("MAE", f"{rm['MAE']:.5f}")
        m2.metric("RMSE", f"{rm['RMSE']:.5f}")
        m3.metric("R²", f"{rm['R2']:.3f}")

        cm = confusion_matrix(result["y_test"], result["rf_test_pred"], labels=[0, 1])
        cm_fig = px.imshow(cm, text_auto=True, x=["Predicted Down", "Predicted Up"],
                           y=["Actual Down", "Actual Up"], title="Random Forest confusion matrix",
                           color_continuous_scale="Blues")
        st.plotly_chart(cm_fig, use_container_width=True)

        st.markdown("**Most influential Random Forest features**")
        imp_fig = px.bar(result["importance"].head(10), x="Importance", y="Feature",
                         orientation="h", title="Top 10 feature importances")
        imp_fig.update_layout(yaxis={"categoryorder": "total ascending"}, template="plotly_white")
        st.plotly_chart(imp_fig, use_container_width=True)

    with tab3:
        st.subheader("Historical risk profile")
        returns = data["Return"].dropna()
        rolling_vol = returns.rolling(20).std() * np.sqrt(252) * 100
        risk_fig = px.line(x=rolling_vol.index, y=rolling_vol.values,
                           labels={"x": "Date", "y": "Annualized volatility (%)"},
                           title="Rolling 20-day annualized volatility")
        risk_fig.update_layout(template="plotly_white")
        st.plotly_chart(risk_fig, use_container_width=True)

        st.write(f"**Current historical volatility category:** {label}")
        st.write(
            "Categories use illustrative thresholds on annualized historical volatility: "
            "below 20% (lower), 20–40% (moderate), and above 40% (higher). "
            "These are project conventions, not universal risk standards."
        )
        drawdown = raw["Close"] / raw["Close"].cummax() - 1
        dd_fig = px.area(x=drawdown.index, y=drawdown.values * 100,
                         labels={"x": "Date", "y": "Drawdown (%)"},
                         title="Historical peak-to-trough drawdown")
        dd_fig.update_layout(template="plotly_white")
        st.plotly_chart(dd_fig, use_container_width=True)

    with tab4:
        st.subheader("Sustainable development connection")
        st.markdown("""
        - **SDG 7 — Affordable and Clean Energy:** compare selected energy-transition
          companies as an illustrative market watchlist.
        - **SDG 8 — Decent Work and Economic Growth:** study market behavior and
          financial-sector information using transparent ML evaluation.
        - **SDG 9 — Industry, Innovation and Infrastructure:** demonstrate data-driven
          analysis and analytical tools.

        The application does not calculate official ESG scores or certify that a company
        is sustainable. The energy-transition list is an illustrative group for academic
        comparison only.
        """)
        st.markdown("**Compare the illustrative watchlist**")
        selected = st.multiselect(
            "Select tickers to compare",
            options=DEFAULT_TICKERS,
            default=ENERGY_TRANSITION_WATCHLIST[:3]
        )
        rows = []
        with st.spinner("Downloading comparison data..."):
            for symbol in selected:
                hist = download_stock(symbol, period)
                if hist.empty or len(hist) < 30:
                    continue
                ret = hist["Close"].pct_change().dropna()
                rows.append({
                    "Ticker": symbol,
                    "Period return (%)": (hist["Close"].iloc[-1] / hist["Close"].iloc[0] - 1) * 100,
                    "Annualized volatility (%)": ret.std() * np.sqrt(252) * 100,
                    "Average daily volume": hist["Volume"].mean()
                })
        if rows:
            compare = pd.DataFrame(rows)
            st.dataframe(compare.style.format({
                "Period return (%)": "{:.2f}",
                "Annualized volatility (%)": "{:.2f}",
                "Average daily volume": "{:,.0f}"
            }), use_container_width=True)

            if len(compare) >= 3:
                cluster_features = compare[["Period return (%)", "Annualized volatility (%)"]]
                scaled = StandardScaler().fit_transform(cluster_features)
                k = min(3, len(compare))
                km = KMeans(n_clusters=k, random_state=42, n_init=10)
                compare["ML Cluster"] = km.fit_predict(scaled).astype(str)
                cluster_fig = px.scatter(
                    compare, x="Annualized volatility (%)", y="Period return (%)",
                    color="ML Cluster", text="Ticker", title="K-Means stock grouping"
                )
                cluster_fig.update_traces(textposition="top center")
                cluster_fig.update_layout(template="plotly_white")
                st.plotly_chart(cluster_fig, use_container_width=True)
                st.caption("Clusters are statistical groupings, not buy/sell ratings.")
        else:
            st.warning("No comparison data available for the selected tickers.")

    with tab5:
        st.subheader("Project methodology")
        st.markdown("""
        **1. Data collection:** daily adjusted OHLCV market data retrieved from Yahoo Finance
        through the `yfinance` Python package.

        **2. Preprocessing:** missing values and infinite values are removed; technical
        indicators and rolling statistics are calculated.

        **3. Feature engineering:** lagged returns, moving averages, RSI, MACD,
        volatility and volume-derived variables are used as model inputs.

        **4. Target construction:** features recorded on day *t* are used to predict
        the return and direction on day *t+1*.

        **5. Validation:** the data is split chronologically (first 80% train, final 20% test).
        Scalers are fitted only on the training segment.

        **6. Evaluation:** classification uses accuracy, precision, recall, F1-score and
        a confusion matrix. Regression uses MAE, RMSE and R².

        **7. Unsupervised learning:** K-Means groups selected stocks using period return
        and annualized volatility.
        """)
        st.markdown("**Important limitations**")
        st.write(
            "Historical patterns may not persist. The simple holdout test does not model "
            "transaction costs, slippage, corporate actions beyond adjusted prices, or "
            "all forms of market regime change. Do not use these outputs alone to make "
            "investment decisions."
        )

st.divider()
st.caption("SML academic prototype • Data provider: Yahoo Finance via yfinance • Not investment advice")
