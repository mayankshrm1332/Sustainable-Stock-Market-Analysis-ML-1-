# Sustainable Stock Market Analysis & Prediction Using ML

A Streamlit-based Statistical Machine Learning (SML) academic project.

## SDG alignment

- **SDG 7 – Affordable and Clean Energy:** illustrative comparison of energy-transition-related listed companies.
- **SDG 8 – Decent Work and Economic Growth:** data-driven analysis of market behavior and economic activity.
- **SDG 9 – Industry, Innovation and Infrastructure:** practical use of data science and ML methods.

The project does **not** calculate official ESG scores or certify company sustainability. The energy-transition watchlist is an illustrative academic selection.

## Features

- Historical adjusted OHLCV data and interactive candlestick chart
- RSI, MACD, moving averages, Bollinger Bands and volume
- Next-trading-day direction classification
- Next-trading-day return regression
- Logistic Regression and Random Forest comparison
- K-Means clustering of selected stocks
- Risk and drawdown visualization
- Streamlit dashboard

## Algorithms

| Algorithm | Use |
|---|---|
| Logistic Regression | Binary next-day direction classification |
| Random Forest Classifier | Binary next-day direction classification |
| Random Forest Regressor | Next-day return estimation |
| K-Means | Unsupervised stock grouping |
| StandardScaler | Feature scaling for Logistic Regression and clustering |

## Requirements

- Python 3.10 or newer (Python 3.11 or 3.12 recommended)
- Internet connection for Yahoo Finance data retrieval
- VS Code or another Python IDE

## Run in VS Code (Windows)

1. Extract the ZIP file.
2. Open the extracted `sustainable_stock_ml` folder in VS Code.
3. Open **Terminal → New Terminal**.
4. Create a virtual environment:

   ```powershell
   py -m venv .venv
   ```

5. Activate it:

   ```powershell
   .\.venv\Scripts\Activate.ps1
   ```

   If PowerShell blocks activation, use Command Prompt:

   ```bat
   .venv\Scripts\activate.bat
   ```

6. Install packages:

   ```powershell
   python -m pip install --upgrade pip
   pip install -r requirements.txt
   ```

7. Start the app:

   ```powershell
   streamlit run app.py
   ```

8. Streamlit will print a local URL, usually `http://localhost:8501`. Open it in your browser.

## Example tickers

Indian NSE tickers generally use `.NS`:

- `TATAPOWER.NS`
- `ADANIGREEN.NS`
- `NTPC.NS`
- `POWERGRID.NS`
- `RELIANCE.NS`
- `TCS.NS`

For US-listed examples, try `AAPL`, `MSFT`, or `NVDA`.

## Methodology and target definition

For each date *t*, the model uses features calculated using data available through date *t* to estimate the following trading day's return:

`Target_Return(t) = Close(t+1) / Close(t) - 1`

The classification label is 1 when the following trading day's return is positive, otherwise 0.

The app uses a chronological 80/20 train/test split. It does not randomly shuffle time-series rows. The scaler for Logistic Regression is fitted on the training segment only.

## Important academic limitations

- The prediction is an experimental estimate, not a reliable forecast or investment recommendation.
- Historical returns and technical indicators do not capture all news, policy changes or macroeconomic events.
- The app does not include transaction costs, slippage or a complete trading backtest.
- A model's probability is not a guaranteed probability of profit.
- K-Means clusters are descriptive groupings, not investment ratings.
- Risk thresholds are illustrative project conventions, not universal financial standards.
- Yahoo Finance data availability and ticker formats can change.

## Suggested project report sections

1. Abstract
2. Introduction and SDG relevance
3. Problem statement and objectives
4. Literature review
5. Dataset description and data preprocessing
6. Feature engineering
7. ML algorithms and mathematical overview
8. Experimental setup and chronological validation
9. Results and evaluation metrics
10. Streamlit implementation and screenshots
11. Limitations and future scope
12. Conclusion and references
