# Project synopsis

## Title
Sustainable Stock Market Analysis and Prediction Using Machine Learning

## Problem statement
Investors and learners face large volumes of financial time-series data. This project builds an educational analytical system that processes historical stock data, derives technical features, compares supervised ML models for next-day movement and return estimation, and groups stocks by return and volatility.

## Objectives
1. Retrieve and visualize historical stock market data.
2. Engineer features from price, volume and technical indicators.
3. Train and compare Logistic Regression and Random Forest classifiers.
4. Estimate next-day returns using Random Forest regression.
5. Use K-Means to explore groups of stocks with similar risk/return characteristics.
6. Present the results in an interactive Streamlit dashboard.
7. Demonstrate links to SDG 7, SDG 8 and SDG 9 without claiming official sustainability certification.

## Research questions
- How do Logistic Regression and Random Forest compare on a chronological holdout set?
- Which engineered variables have the greatest Random Forest feature importance?
- How do selected stocks group when represented by historical return and volatility?
- How does historical volatility change over time?

## Evaluation
Classification: accuracy, precision, recall, F1-score and confusion matrix.
Regression: MAE, RMSE and R-squared.
Clustering: interpret cluster profiles using the return/volatility scatter plot; do not interpret cluster IDs as rankings.

## Future scope
- Walk-forward validation and backtesting with transaction costs.
- Benchmark against a naive majority-class model.
- Add market index and macroeconomic variables.
- Add formal ESG data from a licensed/reputable source.
- Add explainability using permutation importance or SHAP.
- Add model calibration and drift monitoring.
